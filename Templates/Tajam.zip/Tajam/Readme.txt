Hello,
you can use this template for personal or commercial work. don't forget to follow me at dribbble & behance

Thanks

Regards,
Aji